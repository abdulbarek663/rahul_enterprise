# HTML Export

This ZIP file contains the exported HTML content from your Hatch canvas.

## What's Inside:
- index.html: Your main HTML file. Open this to view your project.
- assets/: Your images and media files (37 images included)
  - assets/En4lf6aQGqQoqPnn6yu35.png
  - assets/iE9XCwyEUccNe1pS736Lc.jpeg
  - assets/wR-eyGVYrY8hxPsTRkd7W.jpeg
  - assets/AnB2vQeLh6MTu1XyTKOW2.jpeg
  - assets/aadhar-card.jpeg
  - assets/voter-id.jpeg
  - assets/pf-withdrawal.jpeg
  - assets/pan-card.jpeg
  - assets/health-card.jpeg
  - assets/smart-card.jpeg
  - assets/bank-services.jpeg
  - assets/travel-booking.jpeg
  - assets/documentation.jpeg
  - assets/license-services.jpeg
  - assets/certificates.jpeg
  - assets/passport-service.jpeg
  - assets/pm-kisan.jpeg
  - assets/scholarship.jpeg
  - assets/job-application.jpeg
  - assets/ration-card.jpeg
  - assets/employment-exchange.jpeg
  - assets/resume-building.jpeg
  - assets/data-entry.jpeg
  - assets/online-admission.jpeg
  - assets/challan-payment.jpeg
  - assets/fssai-uddyam.jpeg
  - assets/dtp-services.jpeg
  - assets/bill-payment.jpeg
  - assets/photo-services.jpeg
  - assets/voter-pvc.jpeg
  - assets/pan-pvc.jpeg
  - assets/aadhar-pvc.jpeg
  - assets/eshram-pvc.jpeg
  - assets/abha-pvc.jpeg
  - assets/ayushman-pvc.jpeg
  - assets/rc-pvc.jpeg
  - assets/license-pvc.jpeg


## How to Use It:
1. Open index.html in a web browser. Use a local web server for best results.
2. Upload your files to a hosting service if you're planning to share them online.

## Sharing your Work
Share the entire contents of the ZIP file including the assets folder and its content to preserve images and formatting. Sharing just the index.html file will break the connection to your images.

Generated on: 8/27/2025, 3:11:03 PM
